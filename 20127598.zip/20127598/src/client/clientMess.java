import java.io.*;
import java.util.*;

class clientMess implements Serializable{
    private String id;
    private String message;
    private ArrayList<String> dics;
    private String note;


    clientMess()
    {
        id = null;
        message = null;
        dics = null;
        note = null;
    }

    clientMess(String _id)
    {
        id = _id;
        message = null;
        dics = null;
        note = null;
    }

    clientMess(String _id, String _message)
    {
        id = _id;
        message = _message;
        dics = null;
        note = null;
    }

    clientMess(String _id, String _message, ArrayList<String> _dics)
    {
        id = _id;
        message = _message;
        dics = _dics;
        note = null;
    }

    clientMess(String _id, String _message, ArrayList<String> _dics, String _note)
    {
        id = _id;
        message = _message;
        dics = _dics;
        note = _note;
    }

    public String getID()
    {
        return id;
    }

    public String getMessage()
    {
        return message;
    }

    public ArrayList<String> getDics()
    {
        return dics;
    }

    public String getNote()
    {
        return note;
    }

    public void setID(String _ID)
    {
        id = _ID;
    }

    public void setMessage(String _message)
    {
        message = _message;
    }

    public void setDics(ArrayList<String> _dics)
    {
        dics = _dics;
    }

    public void setNote(String _note)
    {
        note = _note;
    }

    public static byte[] toBytes(clientMess clm)
    {
        try 
        {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(clm);
            oos.close();
            return baos.toByteArray();
        } 
        catch (IOException e) {
            return null;
        }
        
    }

    public static clientMess toObject(byte[] input)
    {
        try 
        {
            
            ByteArrayInputStream bais = new ByteArrayInputStream(input);
            ObjectInputStream ois = new ObjectInputStream(bais);
            clientMess res = (clientMess)ois.readObject();
            ois.close();
            return res;
        }
        catch(IOException e)
        {
            return null;
        }
        catch(ClassNotFoundException cnfe)
        {
            return null;
        }
    }


    public String toString()
    {
        return ("ID: " + id + ", Mess: " + message + ", note: "+ note);
    }

}

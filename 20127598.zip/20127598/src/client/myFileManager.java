
import java.util.*;
import java.io.*;


class myFileManager {
    
    //using BFS
    public static ArrayList<File> getAllFileTree(File root)
    {
        ArrayList<File> fileTree = new ArrayList<File>();
        ArrayList<File> queue = new ArrayList<File>();

        queue.add(root);
        
        while(!queue.isEmpty())
        {
            File file = queue.remove(0);
            fileTree.add(file);
            if(file.isDirectory())
            {
                File[] subFiles = null;
                try
                {
                    subFiles = file.listFiles();
                }
                catch(SecurityException se)
                {
                    subFiles = null;
                }

                if(subFiles == null)
                {
                    continue;
                }
                else
                {
                    for(File subfile: subFiles)
                    {
                        queue.add(subfile);
                    }
                }
            }
        }

        return fileTree;
    }
}

import java.net.*;
import java.time.LocalDateTime;
import java.io.*;
import java.util.*;
import java.lang.Thread;




class myClient
{
    private int TIME_OUT;
    private int MAX_BYTEARRAY_SIZE = 1024*4;
    private int SERVER_PORT;
    private int CLIENT_PORT;
    private DatagramSocket socket;
    private String clientID;

    private boolean isRunning;
    private Thread listenThread;
    private Thread sendingThread;
    private InetAddress hostAddress;


    private volatile String watchingPath;
    private volatile String preparePath;

    private String CONNECT_STRING = "connect_to_server";
    private String QUIT_STRING = "_QUIT_!";
    private String DIRECTORY_STRUCTURE = "#dirstruct";
    private String START_TO_WATCH = "#STARTTOWATCH";
    public String STOP_TRACKING = "#STOPTRACKING";
    public String A_CHANGE_HAPPENED = "#dirchanged";


    myClient()
    {
        TIME_OUT = 5000;
        isRunning = true;
        clientID = "-1";
        SERVER_PORT = 8002;
        CLIENT_PORT = 7998;

        listenThread = null;
        sendingThread = null;
        socket = null;
        preparePath = null;
        watchingPath = null;

    }

    public synchronized void setState(boolean _isRunning)
    {
        isRunning = _isRunning;
    }

    public synchronized void setUpAfterConnectToServer()
    {
        try
        {
            this.socket = new DatagramSocket(CLIENT_PORT);
        }
        catch(SocketException se)
        {
            System.out.println("Error at main socket...");
            return;
        }
        //suppose all path sent by server is correct!
        listenThread = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("listenThread is running...");
                while(isRunning == true)
                {
                    try
                    {
                        byte[] byteArray = new byte[MAX_BYTEARRAY_SIZE];
                        DatagramPacket receivePacket = new DatagramPacket(byteArray, byteArray.length);
                        socket.receive(receivePacket); //wait
                        serverMess serverObject = serverMess.toObject(receivePacket.getData());
                        //converts and delivers data
                        clientID = serverObject.getID();

                        //control
                        if(serverObject.getMessage().equals(START_TO_WATCH) && serverObject.getPath() != null)
                        {
                            File tempCheck = new File(serverObject.getPath());
                            if(tempCheck.isDirectory())
                            {
                                watchingPath = serverObject.getPath();
                                //run the watcher
                                startWatching();
                                /////////////////
                            }
                            else
                            {
                                watchingPath = null;
                            }

                        }
                        else if(serverObject.getMessage().equals(STOP_TRACKING) && serverObject.getID() != null)
                        {
                            watchingPath = null;
                        }
                        else if(serverObject.getMessage().equals(DIRECTORY_STRUCTURE) && serverObject.getID() != null)
                        {
                            preparePath = serverObject.getPath();
                            ArrayList<String> nextDir = getDirectoriesOfRootFile(preparePath);
                            clientMess aMess = new clientMess(clientID, DIRECTORY_STRUCTURE, nextDir);
                            sendMessToServer(aMess);
                        }
                        else if(serverObject.getMessage().equals(QUIT_STRING))//server is closed...
                        {
                            setState(false);
                            Main.ui.switchPanel(false);
                            break;
                        }
                    }
                    catch(IOException e)
                    {
                        System.out.println("Error in listenThread");
                    }
                }
                System.out.println("(*)listenThread is closed...");
                setState(false);
            }
        });

        listenThread.start(); 
    System.out.println("Setup successfully...");
    }



    protected void startWatching()
    {
        if(watchingPath != null)
        {
            //watch any change of the list of directories depending on the watchingPath variable
            //if those subfiles/subfolders have any change, the thread will send notice to the server.
            sendingThread = new Thread(new Runnable() {
                @Override
                public void run()
                {
                    File rootFile = new File(watchingPath);
                    ArrayList<File> fileList = myFileManager.getAllFileTree(rootFile);
                    HashMap<File, Long> lastModifyList = new HashMap<File, Long>();
                    for(File file:fileList)
                    {
                        lastModifyList.put(file, file.lastModified());  
                    }

                    // File[] subFiles = rootFile.listFiles();
                    // ArrayList<String> dics = new ArrayList<String>();
                    // for(int i = 0; )

                    // clientMess notice = new clientMess(clientID, A_CHANGE_HAPPENED, , null);

                    while(watchingPath != null && isRunning == true)
                    {
                        ArrayList<File> currentFileList = myFileManager.getAllFileTree(rootFile);
                        LocalDateTime localDate = LocalDateTime.now();
                        for(File file: currentFileList)
                        {
                            //this file is a new file or a file that was deleted
                            if(!lastModifyList.containsKey(file))
                            {
                                clientMess notice = new clientMess(clientID, A_CHANGE_HAPPENED, null, null);
                                //the unidentified file is a new file.
                                if(currentFileList.size() > fileList.size())
                                {
                                    System.out.println("Changed: a new " + file.getPath());
                                    notice.setNote(localDate.toString() + ":create " + file.toString());
                                }
                                else if(currentFileList.size() < fileList.size())
                                {
                                    System.out.println("Changed: the " + file.getPath() + " was deleted...");
                                    notice.setNote(localDate.toString()+":deteled " + file.toString());
                                }
                                else
                                {
                                    System.out.println("Change: unknown " + file.getPath());
                                    notice.setNote(localDate.toString()+":unknown change to " + file.toString());
                                }
                                
                                byte[] toBytesMess = clientMess.toBytes(notice);
                                DatagramPacket packet = new DatagramPacket(toBytesMess, toBytesMess.length, hostAddress, SERVER_PORT);
                                try 
                                {
                                    socket.send(packet);
                                } catch (IOException e) 
                                {
                                    System.out.println("Cannot send changed notice to server...");
                                }
                                fileList = myFileManager.getAllFileTree(rootFile);
                                lastModifyList = new HashMap<File, Long>();
                                for(File file2: fileList)
                                {
                                    lastModifyList.put(file2, file2.lastModified());
                                }
                                break;
                            }   
                            else if(file.lastModified() != lastModifyList.get(file))
                            {

                                System.out.println("Has change at file " + file.getPath());
                                clientMess notice = new clientMess(clientID, A_CHANGE_HAPPENED, null, localDate.toString()+":modified "+file.toString());

                                byte[] toBytesMess = clientMess.toBytes(notice);
                                DatagramPacket packet = new DatagramPacket(toBytesMess, toBytesMess.length, hostAddress, SERVER_PORT);
                                try 
                                {
                                    socket.send(packet);
                                } catch (IOException e) 
                                {
                                    System.out.println("Cannot send changed notice to server...");
                                }
                                fileList = myFileManager.getAllFileTree(rootFile);
                                lastModifyList = new HashMap<File, Long>();
                                for(File file2: fileList)
                                {
                                    lastModifyList.put(file2, file2.lastModified());
                                }
                                break;
                            }

                        }
                    }
                    System.out.println("(*)client stopped to watching " + rootFile);
                }
            });
            sendingThread.start();
        }

    }

    public synchronized boolean connectToServer(String hostName)
    {
        try
        {
            socket = null;
            //hello server
            hostAddress = InetAddress.getByName(hostName);
            clientMess clm = new clientMess(String.valueOf(clientID), CONNECT_STRING);
            byte[] byteMess = clientMess.toBytes(clm);
            DatagramPacket connectPacket = new DatagramPacket(byteMess, byteMess.length, hostAddress, SERVER_PORT);
            DatagramSocket tempSocket = new DatagramSocket();
            tempSocket.send(connectPacket);
            System.out.println("Client connected to server");

            //wait for server's response
            byte[] serverRespond = new byte[MAX_BYTEARRAY_SIZE];
            DatagramPacket respondPacket = new DatagramPacket(serverRespond, serverRespond.length);
            tempSocket.setSoTimeout(TIME_OUT);
            tempSocket.receive(respondPacket);

            serverMess serverMessage = serverMess.toObject(serverRespond);

            System.out.println(serverMessage);
            this.clientID = serverMessage.getID();
            
            //if server responds, send root of directories
            File[] roots = File.listRoots();
            ArrayList<String> sendRootList = new ArrayList<String>();
            for(File root: roots)
            {
                sendRootList.add(root.getPath());
            }
            clientMess sendMess = new clientMess(clientID, DIRECTORY_STRUCTURE, sendRootList);
            byteMess = clientMess.toBytes(sendMess);
            DatagramPacket initPacket = new DatagramPacket(byteMess, byteMess.length, hostAddress, SERVER_PORT);
            tempSocket.send(initPacket);

            CLIENT_PORT = tempSocket.getLocalPort();
            if(CLIENT_PORT == -1)
            {
                CLIENT_PORT = 7998;
            }
            tempSocket.close();
            return true;
        }
        catch(IOException e) // including SocketTimeOutException, UnknownHostException
        {
            System.out.println(e);
            return false;
        }
        catch(IllegalArgumentException ie)
        {
            System.out.println(ie);
            return false;
        }
    }

    protected synchronized ArrayList<String> getDirectoriesOfRootFile(String rootFile)
    {
        ArrayList<String> res = new ArrayList<String>();
        if(rootFile == null)
        {
            return null;
        }
        else if(rootFile.equals("#GET-ROOT"))
        {
            File[] rootDir = File.listRoots();
            for(File file : rootDir)
            {
                res.add(file.getPath());
            }
            return res;
        }
        File root = new File(rootFile);
        File[] listFiles = root.listFiles();
        
        if(listFiles != null)
        {
            for(File file:listFiles)
            {
                if(file.isDirectory())
                {
                    res.add(file.getAbsolutePath());
                }
            }
        }
        if(listFiles == null || res.size() == 0)
        {
            return null;
        }
        return res;
    }
    
    protected boolean sendMessToServer(clientMess message)
    {
        if(message == null || socket == null)
        {
            return false;
        }
        try
        {
            byte[] byteMess = clientMess.toBytes(message);
            DatagramPacket initPacket = new DatagramPacket(byteMess, byteMess.length, hostAddress, SERVER_PORT);
            this.socket.send(initPacket);
            return true;
        }
        catch(IOException e)
        {
            System.out.println(e);
            return false;
        }
    }

    public void sendQUIT_toServer()
    {
        clientMess quitMess = new clientMess(clientID, QUIT_STRING);
        sendMessToServer(quitMess);
        setState(false);
        socket.close();
    }
}   

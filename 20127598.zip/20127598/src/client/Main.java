import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class Main {
    public static myClient client;
    public static ClientUI ui;
    public static void main(String[] args) {
        client = new myClient();
        ui = new ClientUI();
        ui.runUI();
    }
}

class ClientUI
{
    private CardLayout controlLayout;
    private boolean state;
    private JButton mybutton;
    private JPanel controlPanel;
    private JPanel mainPanel;
    private JPanel connectPanel;
    private JPanel unconnectPanel;
    private JFrame frame;
    private JTextField serverAddField;

    private String UNCONNECTED_STRING = "unconnectedP";
    private String CONNECTED_STRING = "connectedP";


    ClientUI()
    {
        frame = new JFrame();
        controlLayout = new CardLayout(10, 10);
        controlPanel = new JPanel();
        mainPanel = new JPanel(controlLayout);

        state = false;

        unconnectPanel = new JPanel(new BorderLayout());
        // unconnectPanel.setSize(new Dimension(300, 300));
        connectPanel = new JPanel();
        // connectPanel.setSize(new Dimension(300, 300));

        JPanel body = new JPanel(new FlowLayout(FlowLayout.LEADING));
        JLabel serverAddLabel = new JLabel("Input server InetAddress:");
        serverAddField = new JTextField(20);
        body.add(serverAddLabel);
        body.add(serverAddField);

        unconnectPanel.add(body, BorderLayout.CENTER);


        mainPanel.add(unconnectPanel, this.UNCONNECTED_STRING);
        mainPanel.add(connectPanel, this.CONNECTED_STRING);


        mybutton = new JButton("Connect to Server");
        controlPanel.add(mybutton);

        mybutton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                System.out.println("Button is clicked...");
                String serverAddress = serverAddField.getText();
                if(state == false && !serverAddress.equals("")) //unconnected
                {
                    state = true;
                    state = Main.client.connectToServer(serverAddress);
                    if(state == false)//server is full or invalid serverAddress
                    {
                        JOptionPane.showMessageDialog(null, new String("Failed to connect to the server:" + serverAddress), serverAddress, JOptionPane.CLOSED_OPTION);
                    }
                    else
                    {
                        Main.client.setUpAfterConnectToServer();
                        switchPanel(state);
                        mybutton.setText("Disconnect to server");
                    }
                }
                else if(state == true)//connecting
                {
                    state = false;
                    Main.client.sendQUIT_toServer();
                    switchPanel(state);
                    mybutton.setText("Connect to server");
                }
            }
        });

        mybutton.addKeyListener(new KeyListener()
        {
            public void keyTyped(KeyEvent e) {
            }
     
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    System.out.println("Button is clicked...");
                    String serverAddress = serverAddField.getText();
                    if(state == false && !serverAddress.equals("")) //unconnected
                    {
                        state = true;
                        boolean isSuccessful = Main.client.connectToServer(serverAddress);
                        if(isSuccessful == false)//server is full or invalid serverAddress
                        {
                            JOptionPane.showMessageDialog(null, new String("Failed to connect to the server:" + serverAddress), serverAddress, JOptionPane.CLOSED_OPTION);
                        }
                        else
                        {
                            Main.client.setUpAfterConnectToServer();
                            switchPanel(state);
                            mybutton.setText("Disconnect to server");
                        }
                    }
                    else if(state == true)//connecting
                    {
                        state = false;
                        Main.client.sendQUIT_toServer();
                        switchPanel(state);
                        mybutton.setText("Connect to server");
                    }
                }
            }
     
            public void keyReleased(KeyEvent e) {
            }
        });

        frame.addWindowListener(new WindowListener()
        {
           
            @Override
            public void windowOpened(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowClosing(WindowEvent e) {
                // TODO Auto-generated method stub
                if(state == true)//is running
                {
                    Main.client.sendQUIT_toServer();
                    state = false;
                    switchPanel(state);
                }
                // else
                // {
                //     System.exit(0);
                // }
            }

            @Override
            public void windowClosed(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowIconified(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowDeiconified(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowActivated(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }
        });

        frame.add(mainPanel, BorderLayout.CENTER);
        frame.add(controlPanel, BorderLayout.PAGE_END);
    }

    public void switchPanel(Boolean _state)
    {
        if(_state == true)//switch to CONNECTED_PANEL
        {
            this.controlLayout.show(mainPanel, CONNECTED_STRING);
        }
        else
        {
            this.controlLayout.show(mainPanel, UNCONNECTED_STRING);
        }
    }

    protected void createAndShowGUI()
    {
        this.frame.setDefaultLookAndFeelDecorated(true);
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        controlLayout.show(mainPanel, UNCONNECTED_STRING);

        this.frame.setSize(300, 300);
        this.frame.setLocationRelativeTo(null);
        this.frame.setVisible(true);
    }

    public void runUI()
    {
        javax.swing.SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                createAndShowGUI();
            }
        });
    }

}

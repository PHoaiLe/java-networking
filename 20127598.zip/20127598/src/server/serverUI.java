import java.awt.*;
import java.util.Vector;
import java.util.Hashtable;
import javax.swing.*;
import java.awt.event.*;



class serverUI {
    private JFrame frame;
    private JPanel mainPanel;
    private String appName = "Client Tracking";
    private Vector<String> representclientPool;
    private Vector<String> representfolderPool;
    private Vector<String> representhistory;
    private JTextArea pathField;
    private JLabel status;
    private JButton backButton;
    private JButton forwardButton;
    private JButton trackButton;
    private JButton untrackButton;
    private JList<String> clientPoolList;
    private JList<String> folderList;
    private JList<String> historyList;

    // private Hashtable<String, Vector<String>> folderPool;
    private Hashtable<String, Vector<String>> historyPool;

    private Hashtable<String,String> currentPath;
    private String representClientID;
    
    serverUI()
    {
        representclientPool = new Vector<String>();

        currentPath = new Hashtable<String, String>();
        representfolderPool = new Vector<String>();
        representhistory = new Vector<String>();

        // folderPool = new Hashtable<String, Vector<String>>();
        historyPool = new Hashtable<String, Vector<String>>();

        representClientID = null;
    }

    protected void addComponentContent()
    {
        mainPanel = new JPanel();


        JLabel introduceLabel = new JLabel("CLIENT TRACKING");
        introduceLabel.setHorizontalAlignment(JLabel.CENTER);
        //introduceLabel.setSize(new Dimension(100,50));
        introduceLabel.setPreferredSize(new Dimension(100,50));
        JLabel clientPoolLabel = new JLabel("Connected clients:");
        JLabel folderLabel = new JLabel("Folder:");
        JLabel historyLabel = new JLabel("History:");

        status = new JLabel("Status:");
        status.setHorizontalAlignment(JLabel.CENTER);

        /////////////////////////////////////////////////////////////////////////
        introduceLabel.setSize(20, 10);

        JPanel bodyPanel = new JPanel();
        bodyPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(1,1,1,1);
        bodyPanel.setPreferredSize(new Dimension(800, 600));
        
        ///client pool//////////////////////////
        clientPoolList = new JList<String>(representclientPool);
        clientPoolList.setLayoutOrientation(JList.VERTICAL);
        JScrollPane clientScrollPane = new JScrollPane(clientPoolList, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        clientScrollPane.setPreferredSize(new Dimension(100, 368));
        
        
        folderList = new JList<String>(representfolderPool);
        folderList.setLayoutOrientation(JList.VERTICAL);
        JScrollPane folderScrollPane = new JScrollPane(folderList, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        folderScrollPane.setPreferredSize(new Dimension(200, 300));

        historyList = new JList<String>(representhistory);
        historyList.setLayoutOrientation(JList.VERTICAL);
        JScrollPane historyScrollPane = new JScrollPane(historyList, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        historyScrollPane.setPreferredSize(new Dimension(300, 368));


        //clientPool//////////////////////////////////////////////////
        JPanel clientPanel = new JPanel(new BorderLayout());
        clientPanel.add(clientPoolLabel, BorderLayout.PAGE_START);
        clientPanel.add(clientScrollPane, BorderLayout.CENTER);

        //Folder////////////////////////////////////////////////////
        backButton = new JButton("<<");
        forwardButton = new JButton(">>");
        trackButton = new JButton("Track");
        untrackButton = new JButton("Stop!");

        pathField = new JTextArea("", 1, 20);
        JScrollPane pathFieldScrollPane = new JScrollPane(pathField, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        JPanel folderSet2 = new JPanel();
        folderSet2.setLayout(new FlowLayout(FlowLayout.LEADING, 3, 1));
        folderSet2.add(folderLabel);
        folderSet2.add(backButton);
        folderSet2.add(forwardButton);
        folderSet2.add(trackButton);
        folderSet2.add(untrackButton);

        JPanel folderSet1 = new JPanel();
        folderSet1.add(folderLabel);
        folderSet1.add(pathFieldScrollPane);

        JPanel folderSet = new JPanel(new BorderLayout(5, 5));
        folderSet.add(folderSet1, BorderLayout.PAGE_START);
        folderSet.add(folderSet2, BorderLayout.CENTER);
        folderSet.add(folderScrollPane, BorderLayout.PAGE_END);

        //History////////////////////////////////////////////////////////////////////
        JPanel histoJPanel = new JPanel(new BorderLayout(5, 5));
        histoJPanel.add(historyLabel, BorderLayout.PAGE_START);
        histoJPanel.add(historyScrollPane, BorderLayout.CENTER);


        //clientPool////////////////////////////////////
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 10, 8, 15);
        bodyPanel.add(clientPanel, gbc);

        /////////////////////////////////////////////////
        //folderPool/////////////////////////////////////
    
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 15, 8, 15);
        bodyPanel.add(folderSet, gbc);

        //////////////////////////////////////////////////
        //historyPool/////////////////////////////////////
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.ipadx = 2;
        gbc.insets = new Insets(0, 15, 8, 10);
        bodyPanel.add(histoJPanel, gbc);


        //load data//////////////////////////////////////////////////////////////////////////////
        // representclientPool = Main.server.getClientPool();
        // for(int i=0; i< representclientPool.size() ; i++)
        // {
            
        // }

        //Add item's action//////////////////////////////////////////////////////////////
        clientPoolList.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // TODO Auto-generated method stub
                if(e.getClickCount() == 1)
                {
                    String selectedValue = clientPoolList.getSelectedValue();
                    int selectedIndex = clientPoolList.getSelectedIndex();
                    if(selectedValue != null)
                    {
                        if(selectedValue.contains("?"))
                        {
                            selectedValue = "*" + selectedValue.substring(1);
                            representclientPool.set(selectedIndex, selectedValue);
                            clientPoolList.setListData(representclientPool);
                        }
                        String[] values = selectedValue.split("#");
                        representClientID = values[1];
                        representfolderPool = Main.server.getListOfDirectoriesByClientID(values[1]);
                        folderList.setListData(representfolderPool);
                        pathField.setText(currentPath.get(representClientID));

                        // representhistory.clear();
                        representhistory = historyPool.get(representClientID);
                        historyList.setListData(representhistory);
                    }
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // TODO Auto-generated method stub
                
            }
        });

        folderList.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent e) {
                if(e.getClickCount() == 1)
                {
                    int selectedIndex = folderList.getSelectedIndex();
                    if(selectedIndex > -1 && representClientID != null)
                    {
                        Vector<String> folders = Main.server.getListOfDirectoriesByClientID(representClientID);
                        currentPath.replace(representClientID, folders.get(selectedIndex));
                        pathField.setText(folders.get(selectedIndex));
                    }
                }
                else if(e.getClickCount() >= 2)
                {
                    String requestPath = currentPath.get(representClientID);
                    Main.server.add_serverMess_intoOutputQueue(representClientID, Main.server.DIRECTORY_STRUCTURE, requestPath);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {}

            @Override
            public void mouseEntered(MouseEvent e) {}

            @Override
            public void mouseExited(MouseEvent e) {}
            
        });

        backButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                String requestPath = currentPath.get(representClientID);

                if(requestPath == null)
                {
                    JOptionPane.showMessageDialog(null, new String("Please choose folder first..."), new String("Notice"), JOptionPane.CLOSED_OPTION);

                }
                if(requestPath.contains("\\") == false)
                {
                    JOptionPane.showMessageDialog(null, new String(requestPath + "is root directory..."), new String("Notice"), JOptionPane.CLOSED_OPTION);
                }
                else
                {
                    int start = requestPath.lastIndexOf("\\");
                    requestPath = requestPath.replace(requestPath.substring(start), "");
                    currentPath.replace(representClientID, requestPath);
                    if(requestPath.contains("\\") == false)
                    {
                        requestPath = "#GET-ROOT";
                    }
                    
                    pathField.setText(currentPath.get(representClientID));
                    Main.server.add_serverMess_intoOutputQueue(representClientID, Main.server.DIRECTORY_STRUCTURE, requestPath);
                }
            }
        });

        forwardButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                String requestPath = currentPath.get(representClientID);
                if(requestPath == null)
                {
                    JOptionPane.showMessageDialog(null, new String("Please choose a directory..."), new String("Notice"), JOptionPane.CLOSED_OPTION);   
                }
                else if(folderList.getSelectedIndex() == -1)
                {
                    JOptionPane.showMessageDialog(null, new String("Please choose a directory..."), new String("Notice"), JOptionPane.CLOSED_OPTION);
                }
                else
                {
                    boolean check = Main.server.add_serverMess_intoOutputQueue(representClientID, Main.server.DIRECTORY_STRUCTURE, requestPath);
                    if(check == false)
                    {
                        System.out.println("Cannot add request into outputQueue...");
                    }
                    else
                    {
                        System.out.println("Request was added into outputQueue...");
                    }
                }
            }
        });

        trackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                if(representClientID == null)
                {
                    return;
                }
                String trackPath = currentPath.get(representClientID);
                if(trackPath == null)
                {
                    JOptionPane.showMessageDialog(null, new String("Please choose a folder for tracking!"), new String("Notice"), JOptionPane.CLOSED_OPTION);
                }
                else if(trackPath.equals(""))
                {
                    JOptionPane.showMessageDialog(null, new String("Please choose a folder for tracking!"), new String("Notice"), JOptionPane.CLOSED_OPTION);
                }
                else if(trackPath.contains("\\") == false || (trackPath.indexOf("\\") == trackPath.length()-1))
                {
                    int option = JOptionPane.showConfirmDialog(null, new String(trackPath + "(a root disk) can exceed the ability of tracking!\n You mau receive some delayed response!\nWe suggest that you should go deeper into the folder structure!.\nConfirm to track?"), new String("Notice"), JOptionPane.YES_NO_OPTION);
                    if(option == 0)//YES
                    {
                        Main.server.add_serverMess_intoOutputQueue(representClientID, Main.server.START_TO_WATCH, trackPath);
                        int selectedIndex = clientPoolList.getSelectedIndex();
                        representclientPool.set(selectedIndex, "*"+ representclientPool.get(selectedIndex));
                        clientPoolList.setListData(representclientPool);
                    }
                }
                else
                {
                    int selectedIndex = clientPoolList.getSelectedIndex();
                    if((clientPoolList.getSelectedValue().contains("*")== true) || (clientPoolList.getSelectedValue().contains("?")== true))
                    {
                        int option = JOptionPane.showConfirmDialog(null, new String("This client is being tracked. Do you want to add a new tracker?"), new String("Confirm"), JOptionPane.YES_NO_OPTION);
                        if(option == 1)//NO
                        {
                            return;
                        }
                        String str = representclientPool.get(selectedIndex);
                        str = "*"+str.substring(1);
                        representclientPool.set(selectedIndex, str);
                    }
                    else
                    {
                        representclientPool.set(selectedIndex, "*"+ representclientPool.get(selectedIndex));
                    }
                    Main.server.add_serverMess_intoOutputQueue(representClientID, Main.server.START_TO_WATCH, trackPath);
                    clientPoolList.setListData(representclientPool);
                }
            }
        });

        untrackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                int selectedClientIndex = clientPoolList.getSelectedIndex();
                if(representClientID == null)
                {
                    return;
                }
                else if(selectedClientIndex < 0)
                {
                    JOptionPane.showMessageDialog(null, new String("Please choose the client to stop tracking!"), new String("Notice"), JOptionPane.CLOSED_OPTION);
                    return;
                }
                else if(representclientPool.get(selectedClientIndex).contains("*") == false)
                {
                    JOptionPane.showMessageDialog(null, new String("This client had not been tracking!"), new String("Notice"), JOptionPane.CLOSED_OPTION);
                    return;
                }

                Main.server.add_serverMess_intoOutputQueue(representClientID, Main.server.STOP_TRACKING, null);
                String clientString = representclientPool.get(selectedClientIndex);
                clientString = clientString.substring(1);
                representclientPool.set(selectedClientIndex, clientString);
                clientPoolList.setListData(representclientPool);
            }
        });

        /////////////////////////////////////////////////////////////////////////////////
        frame.add(introduceLabel, BorderLayout.PAGE_START);
        frame.add(bodyPanel, BorderLayout.CENTER);
        frame.add(status, BorderLayout.PAGE_END);
    }

    protected void createAndShowGUI()
    {
        this.frame = new JFrame();
        this.frame.setTitle(appName);
        this.frame.setDefaultLookAndFeelDecorated(true);
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.frame.setSize(new Dimension(800, 600));
        
        addComponentContent();

        this.frame.addWindowListener(new WindowListener()
        {

            @Override
            public void windowOpened(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }
 
            @Override
            public void windowClosing(WindowEvent e) {
                // TODO Auto-generated method stub
                for(int i=0; i<representclientPool.size(); i++)
                {
                    String name = representclientPool.get(i);
                    String[] values = name.split("#");
                    Main.server.add_serverMess_intoOutputQueue(values[1], Main.server.QUIT_STRING, null);
                }
                Main.server.closeServer();
            }

            @Override
            public void windowClosed(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowIconified(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowDeiconified(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowActivated(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
                // TODO Auto-generated method stub
                
            }
            
        });
        this.frame.setLocationRelativeTo(null);
        this.frame.setVisible(true);
    }

    public void runUI()
    {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run()
            {
                createAndShowGUI();
            }
        });
    }

    public synchronized void setNewClient(String newClientID)
    {
        representclientPool.add("Client#" + newClientID);
        // Vector<String> folders = Main.server.getListOfDirectoriesByClientID(newClientID);
        // // folderPool.put(newClientID, folders);
        
        historyPool.put(newClientID, new Vector<String>());
        currentPath.put(newClientID, new String(""));
        clientPoolList.setListData(representclientPool);

        return;
    }

    public synchronized void setFolderPool(String clientID)
    {
        if(!Main.server.isClientIDValid(clientID))
        {
            return;
        }
        Vector<String> folders = Main.server.getListOfDirectoriesByClientID(clientID);
        // folderPool.replace(clientID, folders);
        if(representClientID != null && representClientID.equals(clientID))
        {
            representfolderPool = folders;
            folderList.setListData(representfolderPool);
        }

        return;
    }

    public synchronized void setHistory(String clientID, String newMessage) //a change was recognized
    {
        if(clientID == null ||Main.server.isClientIDValid(clientID)==false)
        {
            return;
        }
        Vector<String> history = historyPool.get(clientID);
        history.add(newMessage);
        historyPool.replace(clientID, history);
        // if(representClientID != null && representClientID.equals(clientID)==true)
        // {
        //     representhistory.add(newMessage);
        //     historyList.setListData(representhistory);
        // }
        int index = 0;
        String clientString = "";
        for(int i = 0; i< representclientPool.size(); i++)
        {
            if(representclientPool.get(i).contains(clientID)== true)//clientID in the representclientPool is unique
            {
                index = i;
                clientString = representclientPool.get(i);
            }
        }
        clientString = clientString.replace("*", "?");
        representclientPool.set(index, clientString);
        clientPoolList.setListData(representclientPool);
        return;
    }

    public void removeClient(String clientID)
    {
        for(int i = 0; i< representclientPool.size(); i++)
        {
            if(representclientPool.get(i).contains(clientID))
            {
                representclientPool.remove(i);
                historyPool.remove(clientID);
                currentPath.remove(clientID);
                clientPoolList.setListData(representclientPool);
                if(clientID.equals(representClientID))
                {
                    representfolderPool.clear();
                    representhistory.clear();
                    folderList.setListData(representfolderPool);
                    historyList.setListData(representhistory);
                    pathField.setText("");
                }
                break;
            }
        }
    }

    // public void removeHistoryOfChanges(String clientID)
    // {
    //     if(historyPool.containsKey(clientID)== false)
    //     {
    //         return;
    //     }
    //     historyPool.remove(clientID);
    // }
}

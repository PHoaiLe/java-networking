import java.net.*;

import java.io.*;
import java.util.*;


class myServer{
    private int SERVER_PORT;
    private int CLIENT_PORT;
    DatagramSocket serverReceiveSocket;
    DatagramSocket serverSendSocket;
    private volatile boolean isServerRunning;
    private int currentConnection;
    private int MAX_BYTEARRAY_SIZE = 1024*4;
    private int MAX_CONNECTION = 10;



    public String HELLO_STRING = "connect_to_server";
    public String QUIT_STRING = "_QUIT_!";
    public String DIRECTORY_STRUCTURE = "#dirstruct";
    public String A_CHANGE_HAPPENED = "#dirchanged";
    public String START_TO_WATCH = "#STARTTOWATCH";
    public String STOP_TRACKING = "#STOPTRACKING";


    //current data list of clients
    private Map<String, ArrayList<String>> clientPool; //<clientID, directories>
    //storing InetAddress of each client connecting to server;
    private Map<String, InetAddress> clientAddress;
    private Map<String, Integer> clientPorts;

    //waiting intput-message pool
    private List<DatagramPacket> inputQueue;
    //waiting output-message pool
    private List<serverMess> outputQueue;

    private Thread listenThread;
    private Thread controllerThread;
    private Thread respondThread;


    myServer()
    {
        try
        {
            
            inputQueue = Collections.synchronizedList(new ArrayList<DatagramPacket>());
            outputQueue = Collections.synchronizedList(new ArrayList<serverMess>());
            SERVER_PORT = 8002;
            CLIENT_PORT = 7998;
            serverReceiveSocket = new DatagramSocket(SERVER_PORT);
            serverSendSocket = new DatagramSocket();
            isServerRunning = true;
            currentConnection = 0;
            clientPool = Collections.synchronizedMap(new HashMap<String, ArrayList<String>>());
            clientAddress = Collections.synchronizedMap(new HashMap<String, InetAddress>());
            clientPorts = Collections.synchronizedMap(new HashMap<String, Integer>());

            //executes all request in the inputQueue queue,
            //converts those requests into data \
            //and delivers them to relevant data pools
            controllerThread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    try
                    {
                        do
                        {
                            if(!inputQueue.isEmpty())
                            {
                                DatagramPacket popRequest;
                                synchronized(inputQueue)
                                {
                                    popRequest = inputQueue.remove(0);
                                }
                                
                                clientMess popMess = clientMess.toObject(popRequest.getData());
                                InetAddress cAddress = popRequest.getAddress();
                                Integer cPort = popRequest.getPort();
                                System.out.println("newClient, id:"+ popMess.getID() + ", p:" + cPort);
                                if((popMess.getID().equals("-1") || popMess.getMessage().equals(HELLO_STRING)) && currentConnection <= MAX_CONNECTION)
                                {
                                    currentConnection += 1;
                                    //create ID for the connection
                                    Random aRandom = new Random();
                                    Integer newID = (aRandom.nextInt(10));
                                    while(clientPool.containsKey(String.valueOf(newID)))
                                    {
                                        newID = (aRandom.nextInt(10));
                                    }
                                    
                                    serverMess response = new serverMess(String.valueOf(newID), HELLO_STRING);
                                    //add new connect to clientPool
                                    synchronized(clientPool)
                                    {
                                        clientPool.put(String.valueOf(newID), new ArrayList<String>());
                                    }
                                    synchronized(clientAddress)
                                    {
                                        clientAddress.put(String.valueOf(newID), cAddress);
                                    }
                                    synchronized(clientPorts)
                                    {
                                        clientPorts.put(String.valueOf(newID), cPort);
                                    }
                                    //add response to outputQueue, the response includes 
                                    synchronized(outputQueue)
                                    {
                                        outputQueue.add(response);
                                    }
                                    Main.ui.setNewClient(String.valueOf(newID));
                                }
                                else if(!popMess.getID().equals("-1") && popMess.getMessage().equals(DIRECTORY_STRUCTURE))
                                {
                                    synchronized(clientPool)
                                    {
                                        if(clientPool.containsKey(popMess.getID()) && popMess.getDics() != null)
                                        {
                                            clientPool.replace(popMess.getID(), popMess.getDics());
                                        }
                                    }
                                    Main.ui.setFolderPool(popMess.getID());
                                }
                                else if(!popMess.getID().equals("-1") && popMess.getMessage().equals(QUIT_STRING))
                                {
                                    synchronized(clientPool)
                                    {
                                        clientPool.remove(popMess.getID());
                                    }
                                    synchronized(clientAddress)
                                    {
                                        clientAddress.remove(popMess.getID());
                                    }
                                    synchronized(clientPorts)
                                    {
                                        clientPorts.remove(popMess.getID());
                                    }
                                    Main.ui.removeClient(popMess.getID());
                                }
                                else if(!popMess.getID().equals("-1") && popMess.getMessage().equals(A_CHANGE_HAPPENED))
                                {
                                    // synchronized(clientPool)
                                    // {
                                    //     clientPool.replace(popMess.getID(), popMess.getDics());
                                    // }   
                                    // Main.ui.setFolderPool(popMess.getID());
                                    Main.ui.setHistory(popMess.getID(), popMess.getNote());
                                }
                                
                            }
                            
                        }while(isServerRunning);
                        System.out.println("(*)controllerThread is closed...");
                    }
                    catch(IndexOutOfBoundsException ioobe)
                    {
                        System.out.println(ioobe);
                    }
                }
            });
            
            //listen the request from each client which has connected to the server.
            listenThread = new Thread(new Runnable() {
                @Override
                public void run()
                {
                    do
                    {
                        try
                        {
                            
                            byte[] byteArray = new byte[MAX_BYTEARRAY_SIZE];
                            DatagramPacket request = new DatagramPacket(byteArray, MAX_BYTEARRAY_SIZE);
                            System.out.println("Waiting for client...");
                            //synchronous
                            serverReceiveSocket.receive(request);

                            synchronized(inputQueue)
                            {
                                inputQueue.add(request);
                            }
                        
                        }
                        catch(IllegalArgumentException e)
                        {
                            System.out.println("Error in server side...");
                        }
                        catch(IOException ie)
                        {
                            System.out.println("IOException");
                        }
                    } while(isServerRunning);
                    System.out.println("(*)listenThread is closed...");
                }
            });

            //send the response of the server which is prepared in the outputQueue queue
            //to a specific client via clientAddress.get("Key")-> InetAddress
            respondThread = new Thread(new Runnable() {
                @Override
                public void run()
                {
                    do
                    {
                        try
                        {
                            if(!outputQueue.isEmpty())
                            {
                                serverMess popResponse;
                                InetAddress responseClientAddress;
                                byte[] responseByteArray;
                                Integer responseClientPort;
                                synchronized(outputQueue)
                                {
                                    popResponse = outputQueue.remove(0);
                                    responseByteArray = serverMess.toBytes(popResponse);
                                }
                                synchronized(clientAddress)
                                {
                                    responseClientAddress = clientAddress.get(popResponse.getID());
                                }
                                synchronized(clientPorts)
                                {
                                    responseClientPort = clientPorts.get(popResponse.getID());
                                }

                                DatagramPacket responsePacket = new DatagramPacket(responseByteArray, responseByteArray.length, responseClientAddress, responseClientPort);
                                serverSendSocket.send(responsePacket);
                            }
                        }
                        catch(IOException ioe)
                        {
                            System.out.println("Error in responseThread...");
                        }

                    }while(isServerRunning);
                    System.out.println("(*)respondThread is closed...");
                }
            });

        }
        catch(IOException e)
        {
            System.out.println("Error in server side...");
        }
        
      
    };

    public synchronized boolean add_serverMess_intoOutputQueue(String _clientID, String _message, String _path)
    {
        if(_clientID == null)
        {
            return false;
        }
        serverMess newServerMess = new serverMess(_clientID, _message, _path);
        synchronized(outputQueue)
        {
            outputQueue.add(newServerMess);
        }
        return true;
    }


    public Vector<String> getListOfDirectoriesByClientID(String _clientID)
    {
        Vector<String> data = new Vector<String>();
        if(_clientID == null || _clientID.equals(""))
        {
            return null;
        }
        if(clientPool.containsKey(_clientID))
        {
            synchronized(clientPool)
            {
                ArrayList<String> temp = clientPool.get(_clientID);
                for(int i = 0; i< temp.size(); i++)
                {
                    data.add(temp.get(i));
                }
                return data;
            }
        }
        else
        {
            return null;
        }
    }

    public synchronized Vector<String> getClientPool()
    {
        Set<String> datas = clientPool.keySet();//client ID
        Vector<String> returnedData = new Vector<String>();
        if(datas.size() == 0)
        {
            return null;
        }
        for(String data:datas)
        {
            returnedData.add("Client#" + data);
        }
        return returnedData;
    }

    public synchronized boolean isClientIDValid(String _clientID)
    {
        synchronized(clientPool)
        {
            if(clientPool.containsKey(_clientID)==true)
            {
                return true;   
            }
            else
            {
                return false;
            }
        }
    }

    public synchronized void setState(boolean _isServerRunning)
    {
        this.isServerRunning = _isServerRunning;
    }

    public synchronized void closeServer()
    {
        this.isServerRunning = false;
        serverReceiveSocket.close();
        serverSendSocket.close();
    }

    public void runServer() {
        listenThread.start();
        controllerThread.start();
        respondThread.start();
    }
}


public class Main {
    public static myServer server;
    public static serverUI ui;
    public static void main(String[] args) {
        server = new myServer();
        ui = new serverUI();
        server.runServer();
        ui.runUI();
    }
}



import java.io.*;
import java.util.*;


class serverMess implements Serializable{
    private String message;
    private String ID;
    private String path;


    serverMess()
    {
        message = null;
        ID = null;
        path = null;
    }
    
    serverMess(String _message)
    {
        ID = null;
        message = _message;
        path = null;
    }

    serverMess(String _ID, String _message)
    {
        ID = _ID;
        message = _message;
        path = null;
    }


    serverMess(String _ID, String _message, String _path)
    {
        ID = _ID;
        message = _message;
        path = _path;
    }

    public static byte[] toBytes(serverMess svm)
    {
        try
        {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(svm);
            oos.close();
            return baos.toByteArray();
        }
        catch(IOException e)
        {
            System.out.println("error in serverMess");
            return null;
        }
    }

    public static serverMess toObject(byte[] input)
    {
        try
        {
            ByteArrayInputStream bais = new ByteArrayInputStream(input);
            ObjectInputStream ois = new ObjectInputStream(bais);
            serverMess res = (serverMess)ois.readObject();
            return res;
        }
        catch(IOException e)
        {
            return null;
        }
        catch(ClassNotFoundException cnfe)
        {
            return null;
        }

    }

    public String getMessage()
    {
        return this.message;
    }

    public String getID()
    {
        return this.ID;
    }

    public String toString()
    {
        return this.ID + " " + this.message;
    }

    public String getPath()
    {
        return this.path;
    }

    public void setID(String _ID)
    {
        this.ID = _ID;
    }

    public void setMessage(String _message)
    {
        this.message = _message;
    }

    public void setPath(String _path)
    {
        this.path = _path;
    }
}
